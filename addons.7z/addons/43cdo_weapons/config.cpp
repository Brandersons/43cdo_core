class CfgPatches
{
    class 43cdo_weapons
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        addonRootClass = "43cdo_core";
        requiredAddons[] = {
            "43cdo_core",
            "A3_Characters_F",
            "scm_l403A1",
            "scm_attachments",
            "UKSF_LMT"
        };
    };
};

class CfgWeapons
{
    class SCM_L403A1_Tan;
    class 43cdo_weapons_l403a1 : SCM_L403A1_Tan
    {
        displayName = "L403A1";
        scope = 2;

        class LinkedItems
        {
            class LinkedItemsOptic
            {
                slot = "CowsSlot";
                item = "SCM_Eleanor";
            };
            class LinkedItemsAcc
            {
                slot = "PointerSlot";
                item = "UK3CB_BAF_LLM_IR_Tan";
            };
            class LinkedItemsMuzzle
            {
                slot = "MuzzleSlot";
                item = "SCM_PRT_Cover";
            };
            class LinkedItemsUnder
            {
                slot = "UnderBarrelSlot";
                item = "rhsusf_acc_grip2_tan";
            };
        };
    };
};

class cfgVehicles
{
    class Weapon_arifle_SPAR_01_blk_F;
    class 43cdo_weapons_l85a3_prop : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "L85a3";
        scope = 2;
        model = "\UK3CB_BAF_Weapons\addons\UK3CB_BAF_Weapons_L85A3\uk3cb_L85A3.p3d";
    };
    class 43cdo_weapons_l403a1_prop : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "L403A1";
        scope = 2;
        model = "\Scotts_L403A1\Models\KS1_tan.p3d";
    };
    class 43cdo_weapons_l403a1_prop_magazine : Weapon_arifle_SPAR_01_blk_F
    {
        displayname = "EMAG 30rnd 556x45 M855A1 EPR";
        scope = 2;
        model = "Scotts_EMAG\Models\EMAG_Magpul.p3d";
    };
    class 43cdo_weapons_l403a1_prop_scope : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "[SCM] Vortex Eleanor";
        scope = 2;
        model = "Scotts_Attachments\Models\Eleanor.p3d";
    };
    class 43cdo_weapons_l403a1_prop_muzzle : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "[SCM] KAC 556 PRT";
        scope = 2;
        model = "Scotts_Attachments\Models\PRT_Cover.p3d";
    };
    class 43cdo_weapons_l129a2_prop : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "L129A2 6.5 Creedmoor";
        scope = 2;
        model = "UKSF_LMT\L129A2.p3d";
    };
    class 43cdo_weapons_l129a2_prop_magazine : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "20Rnd 6.5Creedmoor Sierra Matchking ";
        scope = 2;
        model = "43cdo_weapons\data\EMAG_Magpul.p3d";
    };
    class 43cdo_weapons_l7a2_prop : Weapon_arifle_SPAR_01_blk_F
    {
        displayName = "L7A2";
        scope = 2;
        model = "UK3CB_BAF_Weapons\addons\UK3CB_BAF_Weapons_L7\UK3CB_L7A2.p3d";
    };
};