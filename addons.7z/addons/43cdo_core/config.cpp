class CfgPatches
{
	class 43cdo_core
	{
		name="[43CDO] Core";
		author="LCpl. BT";
		url="";
		requiredAddons[]= 
		{
			"3DEN",
			"A3_Characters_F",
			"a3_ui_f",
			"a3_ui_f_aow",
			"a3_ui_f_enoch",
			"a3_ui_f_orange",
			"a3_ui_f_oldman",
			"a3_ui_f_tacops",
			"ef_ui",
			"scm_l403A1",
			"scm_attachments",
			"UKSF_LMT"
		};
		requiredVersion= 0.01;
		units[]={};
		weapons[]={};
		magazines[]={};
	};
};

class CfgFactionClasses
{
    class 43cdo_faction
    {
        displayName = "[43CDO] 43 Commando";
        priority = -25;
        side = 1;
        icon = "";
    };
};

class CfgEditorCategories
{
    class 43cdo_faction_edcat
    {
        displayName = "[43CDO] 43 Commando";
    };
    class 43cdo_faction_edcat_objects
    {
        displayName = "[43CDO] Objects";
    };
};

class CfgEditorSubcategories
{
    class 43cdo_faction_edsubcat_men
    {
        displayName = "[43CDO] Men";
    };
    class 43cdo_faction_edsubcat_infantry
    {
        displayName = "[43CDO] Infantry";
    };
    class 43cdo_faction_edsubcat_playersqm
    {
        displayName = "[43CDO] Players & QM";
    };
    class 43cdo_faction_edsubcat_props
    {
        displayName = "[43CDO] Props";
    };
    class 43cdo_faction_edsubcat_supplies
    {
        displayName = "[43CDO] Supplies";
    };
};

class IdentityTypes
{
    class 43cdo_faction_identity
    {
        name = "[43CDO] 43 Commando";
        face[] = {
            "WhiteHead_01", "WhiteHead_02", "WhiteHead_03", "WhiteHead_04", 
            "WhiteHead_05", "WhiteHead_06", "WhiteHead_07", "WhiteHead_08", 
            "WhiteHead_09", "WhiteHead_10", "WhiteHead_11", "WhiteHead_12", 
            "WhiteHead_13", "WhiteHead_14", "WhiteHead_15", "WhiteHead_16",
            "AfricanHead_01", "AfricanHead_02", "AfricanHead_03",
			"AsianHead_01",   "AsianHead_02", "AsianHead_03"
        };
        glasses[] = {"None"};
        speaker[] = {
            "Male01ENGB",
            "Male02ENGB",
            "Male03ENGB",
            "Male04ENGB", 
            "Male05ENGB"
        };
        pitch[] = {0.95, 1.05};
    };
};