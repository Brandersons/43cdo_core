class CfgPatches
{
	class 43cdo_markers
	{
		name="[43CDO] Markers";
		author="LCpl. BT";
		addonRootClass = "43cdo_core";
		requiredAddons[]= 
		{
			"43cdo_core",
			"a3_ui_f"
		};
		requiredVersion= 0.01;
		units[]={};
		weapons[]={};
	};
};

class CfgMarkers
{
	class 43cdo_marker_baf
	{
		name="[BAF] British Army";
		icon="43cdo_markers\data\RA_Flag.paa";
		color[]={1,1,1,1};
		size= 32;
		shadow = 0;
		scope = 2;
		markerClass = "Flags";
	};
};